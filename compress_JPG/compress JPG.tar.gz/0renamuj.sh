rename 's/Kopia\ //g' *.HEIC
