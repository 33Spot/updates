sudo apt install libheif-examples
