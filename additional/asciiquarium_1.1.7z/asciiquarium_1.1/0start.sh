./asciiquarium
#./asciiquarium | lolcat
#./asciiquarium | lolcat -p 200
#./asciiquarium | lolcat -i -p 200
