sudo apt install cpanminus libcurses-perl
cpan Term::Animation
