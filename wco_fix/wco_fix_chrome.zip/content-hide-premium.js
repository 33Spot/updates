(() => {
    "use strict";

    const STORAGE_KEY = "wco-premium-links-v1";
    const CACHE_TIME = 24 * 60 * 60 * 1000;
    const HIDDEN = "data-wco-premium-hidden";

    let premiumURLs = new Map();

    function urlKey(href) {
        if (!href || href.startsWith("#")) return null;
        try {
            const url = new URL(href, location.href);
            if (!["http:", "https:"].includes(url.protocol)) return null;
            if (!["www.wco.tv", "wco.tv"].includes(url.hostname)) return null;
            const path = url.pathname.replace(/\/+$/, "") || "/";
            return path === "/" ? null : path;
        } catch {
            return null;
        }
    }

    function hideLink(link) {
        const item = link.closest(".pe-episode-card, li") || link;
        item.setAttribute(HIDDEN, "");
    }

    function update() {
        let changed = false;

        document.querySelectorAll(
            "#premium-releases a[href], a.pe-episode-card[href]"
        ).forEach(link => {
            const key = urlKey(link.getAttribute("href"));
            if (key && !premiumURLs.has(key)) {
                premiumURLs.set(key, Date.now() + CACHE_TIME);
                changed = true;
            }
        });

        if (changed) {
            chrome.storage.local.set({ [STORAGE_KEY]: [...premiumURLs] });
        }

        document.querySelectorAll(`[${HIDDEN}]`).forEach(el => {
            el.removeAttribute(HIDDEN);
        });

        document.querySelectorAll("a[href]").forEach(link => {
            if (premiumURLs.has(urlKey(link.getAttribute("href")))) {
                hideLink(link);
            }
        });
    }

    function blockPremiumClick(event) {
        const link = event.target?.closest?.("a[href]");
        if (!link) return;

        const isPremium =
            link.closest("#premium-releases, .pe-episode-card") ||
            premiumURLs.has(urlKey(link.getAttribute("href")));

        if (isPremium) {
            event.preventDefault();
            event.stopImmediatePropagation();
            hideLink(link);
        }
    }

    // Load saved data, then start watching
    chrome.storage.local.get(STORAGE_KEY, (result) => {
        const stored = result[STORAGE_KEY] || [];
        premiumURLs = new Map(
            stored.filter(([, expires]) => expires > Date.now())
        );

        let queued = false;
        new MutationObserver(() => {
            if (queued) return;
            queued = true;
            requestAnimationFrame(() => {
                queued = false;
                update();
            });
        }).observe(document, {
            childList: true,
            subtree: true,
            attributes: true,
            attributeFilter: ["href"]
        });

        document.addEventListener("click", blockPremiumClick, true);
        document.addEventListener("auxclick", blockPremiumClick, true);

        if (document.readyState === "loading") {
            document.addEventListener("DOMContentLoaded", update);
        } else {
            update();
        }
    });
})();
