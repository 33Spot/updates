// ============================================================
//  CORE — Find and DELETE both cookies using their real properties
// ============================================================
async function fixCookies() {
    const cookies = await chrome.cookies.getAll({ domain: 'wcostream.com' });

    for (const c of cookies) {
        const scheme = c.secure ? 'https' : 'http';
        const bare   = c.domain.startsWith('.') ? c.domain.slice(1) : c.domain;
        const url    = `${scheme}://${bare}${c.path}`;

        if (c.name === 'wco_full_capacity') {
            await chrome.cookies.remove({
                url,
                name:    'wco_full_capacity',
                storeId: c.storeId
            });
            console.log(`[WCO Fix] ✂ wco_full_capacity deleted  (${url})`);
        }

        if (c.name === 'PHPSESSID') {
            await chrome.cookies.remove({
                url,
                name:    'PHPSESSID',
                storeId: c.storeId
            });
            console.log(`[WCO Fix] ✂ PHPSESSID deleted  (${url})`);
        }
    }
}


// ============================================================
//  LAYER 1 — Every time a WCO page finishes loading
// ============================================================
chrome.tabs.onUpdated.addListener((tabId, changeInfo, tab) => {
    if (changeInfo.status !== 'complete' || !tab.url) return;
    if (!tab.url.includes('wco')) return;
    fixCookies();fixCookies();fixCookies();
});


// ============================================================
//  LAYER 2 — Real-time: delete the instant the server re-sets them
// ============================================================
chrome.cookies.onChanged.addListener((changeInfo) => {
    if (changeInfo.removed) return;

    const c = changeInfo.cookie;
    if (!c.domain.includes('wcostream.com')) return;

    const scheme = c.secure ? 'https' : 'http';
    const bare   = c.domain.startsWith('.') ? c.domain.slice(1) : c.domain;
    const url    = `${scheme}://${bare}${c.path}`;

    if (c.name === 'wco_full_capacity') {
        chrome.cookies.remove({ url, name: 'wco_full_capacity', storeId: c.storeId });
    }

    if (c.name === 'PHPSESSID') {
        chrome.cookies.remove({ url, name: 'PHPSESSID', storeId: c.storeId });
    }
});
