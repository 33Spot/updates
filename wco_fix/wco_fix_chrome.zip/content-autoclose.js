(function () {
    'use strict';

    function clickCloseButton() {
        const closeBtn = document.querySelector('.btn-close');
        if (closeBtn) {
            closeBtn.click();
            return true;
        }
        return false;
    }

    clickCloseButton();

    const observer = new MutationObserver((mutations) => {
        for (const mutation of mutations) {
            for (const node of mutation.addedNodes) {
                if (node.nodeType === Node.ELEMENT_NODE) {
                    if (node.matches && node.matches('.btn-close')) {
                        node.click();
                    } else if (node.querySelector) {
                        const btn = node.querySelector('.btn-close');
                        if (btn) btn.click();
                    }
                }
            }
        }
    });

    observer.observe(document.body, { childList: true, subtree: true });

    let attempts = 0;
    const interval = setInterval(() => {
        attempts++;
        clickCloseButton();
        if (attempts >= 30) clearInterval(interval);
    }, 500);
})();
