(function () {
    'use strict';

    function removeCountdown() {
        const closeBtn = document.getElementById('close-btn');
        const announcement = document.getElementById('announcement');
        const backdrop = document.getElementById('backdrop');

        if (!closeBtn || !announcement || !backdrop) return false;

        const roll = closeBtn.querySelector('.cd-roll');
        if (roll) {
            roll.style.animation = 'none';
            roll.style.webkitAnimation = 'none';
        }

        closeBtn.disabled = false;
        closeBtn.textContent = 'Close';

        closeBtn.onclick = function (e) {
            e.preventDefault();
            e.stopPropagation();

            announcement.style.opacity = '0';
            backdrop.style.opacity = '0';

            setTimeout(function () {
                announcement.style.display = 'none';
                backdrop.style.display = 'none';

                const base = 'https://embed.wcostream.com/inc/embed/video-js.php';
                const url = window.AdGate && window.AdGate.buildUrl
                    ? window.AdGate.buildUrl(base)
                    : base + window.location.search;

                window.location.replace(url);
            }, 300);
        };

        return true;
    }

    if (!removeCountdown()) {
        const observer = new MutationObserver(function () {
            if (removeCountdown()) observer.disconnect();
        });
        observer.observe(document.documentElement, { childList: true, subtree: true });
    }
})();
